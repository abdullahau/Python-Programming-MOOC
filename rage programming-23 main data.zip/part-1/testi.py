lämpö = 10
lämpö2 = 20
print(lämpö + lämpö2)