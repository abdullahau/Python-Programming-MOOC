---
path: '/part-5'
title: 'Part 5'
overview: true
hidden: false
---

<pages-in-this-section></pages-in-this-section>

<exercises-in-this-section></exercises-in-this-section>
