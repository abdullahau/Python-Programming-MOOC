---
path: '/part-8'
title: 'Part 8'
overview: true
hidden: false
---

<pages-in-this-section></pages-in-this-section>

<exercises-in-this-section></exercises-in-this-section>
