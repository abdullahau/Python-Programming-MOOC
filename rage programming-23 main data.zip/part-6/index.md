---
path: '/part-6'
title: 'Part 6'
overview: true
hidden: false
---

<pages-in-this-section></pages-in-this-section>

<exercises-in-this-section></exercises-in-this-section>
